// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception> // Required for std::exception base class
#include <stdexcept> // Required for standard exceptions like std::runtime_error and std::invalid_argument

// SECURE CODING: Custom exception class derived from std::exception
class CustomAppException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom Application Exception Triggered.";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throw a standard exception to simulate a runtime fault
    throw std::runtime_error("Standard runtime error in do_even_more_custom_application_logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap the call with an exception handler that catches std::exception
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        // Display a message and the exception.what(), then continue processing
        std::cout << "Exception Caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception to be caught in main
    std::cout << "Throwing CustomAppException..." << std::endl;
    throw CustomAppException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors using a standard C++ defined exception
    if (den == 0.0f)
    {
        throw std::invalid_argument("Division by zero error.");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // Create an exception handler to capture ONLY the exception thrown by divide.
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << "Exception Caught in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Create exception handlers that catch custom, standard, and unhandled exceptions in order
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomAppException& e)
    {
        std::cout << "Main Catch (Custom Exception): " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cout << "Main Catch (Standard Exception): " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Main Catch (Catch-All): An unknown exception occurred!" << std::endl;
    }

    return 0;
}