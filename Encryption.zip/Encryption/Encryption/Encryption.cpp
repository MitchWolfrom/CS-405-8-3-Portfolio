// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.[cite: 2]

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key[cite: 2]
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char[cite: 2]
    for (size_t i = 0; i < source_length; ++i)
    {
        // transform each character based on an xor of the key modded constrained to key length using a mod[cite: 2]
        // I used the modulo operator here so we smoothly cycle through the key continuously.[cite: 2]
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text;
    std::ifstream input_file(filename);

    // Making sure the file actually opened before trying to read from it.
    if (input_file.is_open())
    {
        std::stringstream buffer;
        // Read the entire file buffer into the stringstream
        buffer << input_file.rdbuf();
        file_text = buffer.str();
        input_file.close();
    }
    else
    {
        std::cerr << "Error: Unable to open file " << filename << " for reading." << std::endl;
    }

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline[cite: 2]
    size_t pos = string_data.find('\n');
    // did we find a newline[cite: 2]
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name[cite: 2]
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream output_file(filename);

    if (output_file.is_open())
    {
        // Generate the current timestamp
        std::time_t t = std::time(nullptr);
        std::tm now;
        // I swapped this to Microsoft's secure version so Visual Studio stops yelling at us with C4996 errors.
        localtime_s(&now, &t);
        char timestamp[11];

        // Format timestamp to yyyy-mm-dd
        std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d", &now);

        // Save output conforming to required format:
        // Line 1: student name[cite: 2]
        // Line 2: timestamp (yyyy-mm-dd)[cite: 2]
        // Line 3: key used[cite: 2]
        // Line 4+: data[cite: 2]
        output_file << student_name << "\n";
        output_file << timestamp << "\n";
        output_file << key << "\n";
        output_file << data;

        output_file.close();
    }
    else
    {
        std::cerr << "Error: Unable to open file " << filename << " for writing." << std::endl;
    }
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    const std::string student_name = get_student_name(source_string);

    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;
}