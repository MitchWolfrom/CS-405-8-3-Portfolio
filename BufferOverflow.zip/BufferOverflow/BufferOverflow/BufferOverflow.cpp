// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>    // Added for safe input handling
#include <algorithm> // Added for std::copy

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number and user_input declarations remain exactly as requested
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";

    // SECURE CODING: Read input into a dynamically sized string first.
    // This allows us to inspect the size of the payload from PythonWithExploit.py 
    // before moving it to the vulnerable fixed-size array.
    std::string safe_input;
    std::cin >> safe_input;

    // DETECT & PREVENT: Check if input exceeds the 19-character maximum (leaving 1 for null terminator)
    if (safe_input.length() >= sizeof(user_input)) {
        std::cout << "\n*** SECURITY ALERT ***" << std::endl;
        std::cout << "Input of length " << safe_input.length() << " exceeds the 19-character limit." << std::endl;
        std::cout << "Buffer overflow prevented. Truncating input." << std::endl << std::endl;

        // Copy only what fits safely into the buffer and manually null-terminate it
        std::copy(safe_input.begin(), safe_input.begin() + (sizeof(user_input) - 1), user_input);
        user_input[sizeof(user_input) - 1] = '\0';
    }
    else {
        // Input is safe, copy it entirely
        std::copy(safe_input.begin(), safe_input.end(), user_input);
        user_input[safe_input.length()] = '\0';
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}